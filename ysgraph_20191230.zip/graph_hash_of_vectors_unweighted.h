#pragma once


/* define graph: a hash of vectors */
typedef std::unordered_map<int, std::vector<int>> graph_hash_of_vectors_unweighted;


void graph_hash_of_vectors_unweighted_add_vertex(graph_hash_of_vectors_unweighted& input_graph, int vertex) {

	/*time complexity O(1)*/
	/*since unordered_map containers do not allow for duplicate keys,
	all the vertices in subgraph are unique*/

	if (input_graph.count(vertex) == 0) { // vertex is not in input_graph
		input_graph[vertex] = {};
	}

}
