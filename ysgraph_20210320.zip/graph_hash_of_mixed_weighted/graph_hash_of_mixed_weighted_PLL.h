#pragma once

/*PLL*/

#include <Current_Memory_Consumption_of_This_Process.h>

bool PLL_Creating_Indexes_compare(const pair<int, int>& i, pair<int, int>& j)
{
	return i.second > j.second;  // < is from small to big; > is from big to small.  sort by the second item of pair<int, int>
}

struct PLL_node_for_sp {
	int vertex, parent_vertex;
	double priority_value;
}; // define the node in the queue
bool operator<(PLL_node_for_sp const& x, PLL_node_for_sp const& y) {
	return x.priority_value > y.priority_value; // < is the max-heap; > is the min heap
}
typedef typename boost::heap::fibonacci_heap<PLL_node_for_sp>::handle_type PLL_handle_t_for_sp;



void graph_hash_of_mixed_weighted_PLL_Create_Indexes(graph_hash_of_mixed_weighted& input_graph, string index_file_name) {

	/*indexes; L(v_1) = { v_x, <distance to v_x, predecessor of v_x in the SP between v_1 and v_x>}*/
	unordered_map<int, unordered_map<int, pair<double, int>>> L;
	long long int index_size = 0;

	auto begin = std::chrono::high_resolution_clock::now();

	/*sort vertices by degrees*/
	vector<pair<int, int>> sorted_vertices;
	for (auto it = input_graph.hash_of_vectors.begin(); it != input_graph.hash_of_vectors.end(); it++) {
		sorted_vertices.push_back({ it->first, input_graph.degree(it->first) });
		L[it->first] = {};
	}
	sort(sorted_vertices.begin(), sorted_vertices.end(), PLL_Creating_Indexes_compare);



	/*PLL: Pruned Landmark Labeling*/
	for (auto it = sorted_vertices.begin(); it != sorted_vertices.end(); it++) {

		/*Pruned Dijkstra from vertex v_k = it->first; see Algorithm 1 in 2013 Japan SIGMOD paper*/
		int v_k = it->first;

		PLL_node_for_sp node;
		boost::heap::fibonacci_heap<PLL_node_for_sp> Q;
		std::unordered_map<int, double> P; // distance to v_k; priorities in Q
		std::unordered_map<int, PLL_handle_t_for_sp> Q_handles;

		node.vertex = v_k;
		node.parent_vertex = v_k;
		node.priority_value = 0;
		Q_handles[v_k] = Q.push(node);
		P[v_k] = 0;


		while (Q.size() > 0) {

			node = Q.top();
			Q.pop();
			int u = node.vertex;
			int u_parent = node.parent_vertex;
			double P_u = node.priority_value;


			double query_v_k_u = std::numeric_limits<double>::max(); // if disconnected, retun this large value
			auto mm = L.find(u);
			auto nn = L.find(v_k);
			for (auto xx = mm->second.begin(); xx != mm->second.end(); xx++) {
				int v = xx->first;
				if (nn->second.count(v) > 0) {
					double dis = xx->second.first + nn->second[v].first;
					if (query_v_k_u > dis) {
						query_v_k_u = dis;
					}
				}
			}

			if (P_u < query_v_k_u) {

				L[u][v_k] = { P_u, u_parent };
				index_size++;

				auto search = input_graph.hash_of_hashs.find(u);
				if (search != input_graph.hash_of_hashs.end()) {
					for (auto it2 = search->second.begin(); it2 != search->second.end(); it2++) {
						int adj_v = it2->first;
						double ec = it2->second;
						if (P.count(adj_v) == 0) {
							node.vertex = adj_v;
							node.parent_vertex = u;
							node.priority_value = P_u + ec;
							Q_handles[adj_v] = Q.push(node);
							P[adj_v] = node.priority_value;
						}
						else {
							if (P[adj_v] > P_u + ec) {
								node.vertex = adj_v;
								node.parent_vertex = u;
								node.priority_value = P_u + ec;
								Q.update(Q_handles[adj_v], node);
								P[adj_v] = node.priority_value;
							}
						}
					}
				}
				else {
					auto search2 = input_graph.hash_of_vectors.find(u);
					for (auto it2 = search2->second.adj_vertices.begin(); it2 != search2->second.adj_vertices.end(); it2++) {
						int adj_v = it2->first;
						double ec = it2->second;
						if (P.count(adj_v) == 0) {
							node.vertex = adj_v;
							node.parent_vertex = u;
							node.priority_value = P_u + ec;
							Q_handles[adj_v] = Q.push(node);
							P[adj_v] = node.priority_value;
						}
						else {
							if (P[adj_v] > P_u + ec) {
								node.vertex = adj_v;
								node.parent_vertex = u;
								node.priority_value = P_u + ec;
								Q.update(Q_handles[adj_v], node);
								P[adj_v] = node.priority_value;
							}
						}
					}
				}

			}
		}
	}


	auto end = std::chrono::high_resolution_clock::now();
	double runningtime = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() / 1e9; // s

	/*save indexes*/
	std::ofstream outputFile;
	outputFile.precision(6);
	outputFile.setf(std::ios::fixed);
	outputFile.setf(std::ios::showpoint);
	outputFile.open(index_file_name);
	outputFile << "SECTION Comments" << std::endl;
	outputFile << "Creator Yahui SUN ���ǻ�" << std::endl;
	outputFile << "Graph Size: |V|=" << input_graph.hash_of_vectors.size() << " |E|=" << graph_hash_of_mixed_weighted_num_edges(input_graph) << std::endl;
	outputFile << "Total Number of Indexes: " << index_size << " Consumed Time: " << runningtime << "s"
		<< " Consumed RAM: " << Current_Memory_Consumption_of_This_Process() << "MB" << std::endl;
	outputFile << "Number of Indexes Per Vertex: " << (double)index_size / input_graph.hash_of_vectors.size() << std::endl;
	outputFile << "Comments END at Line 6" << std::endl;
	for (auto it = L.begin(); it != L.end(); it++) {
		outputFile << it->first << ":"; // v_1:
		for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
			outputFile << "<" << it2->first << "," << it2->second.first << "," << it2->second.second << ">"; // <v_x,dis,pre>
		}
		outputFile << std::endl;
	}

}




#include <text mining/parse_substring_between_pairs_of_delimiters.h>

unordered_map<int, unordered_map<int, pair<double, int>>> graph_hash_of_mixed_weighted_PLL_Read_Indexes(string index_file_name) {

	/*indexes; L(v_1) = { v_x, <distance to v_x, predecessor of v_x in the SP between v_1 and v_x>}*/
	unordered_map<int, unordered_map<int, pair<double, int>>> L;

	std::string line_content;
	std::ifstream myfile(index_file_name); // open the file
	if (myfile.is_open()) // if the file is opened successfully
	{
		long long int line_id = 0;

		while (getline(myfile, line_content)) // read file line by line
		{
			line_id++;
			if (line_id > 6) {
				std::vector<std::string> Parsed_content = parse_string(line_content, ":");
				if (Parsed_content.size() == 2) {
					int v = stoi(Parsed_content[0]);
					L[v] = {};
					std::vector<string> index_strings = parse_substring_between_pairs_of_delimiters(Parsed_content[1], "<", ">");
					for (auto it = index_strings.begin(); it != index_strings.end(); it++) {
						std::vector<string> an_index = parse_string(*it, ",");
						L[v][stoi(an_index[0])] = { stod(an_index[1]), stoi(an_index[2]) };
						//cout << stoi(an_index[0]) << "," << stod(an_index[1]) << "," << stoi(an_index[2]) << endl;
						//getchar();
					}
				}
			}
		}
		myfile.close(); //close the file

		return L;
	}
	else
	{
		std::cout << "Unable to open file " << index_file_name << std::endl
			<< "Please check the file location or file name." << std::endl; // throw an error message
		getchar(); // keep the console window
		exit(1); // end the program
	}



}


double graph_hash_of_mixed_weighted_PLL_extract_distance(unordered_map<int, unordered_map<int, pair<double, int>>>& L, int source, int terminal) {

	/*return std::numeric_limits<double>::max() is not connected*/

	double distance = INT_MAX;
	auto mm = L.find(source);
	auto nn = L.find(terminal);
	for (auto xx = mm->second.begin(); xx != mm->second.end(); xx++) {
		int v = xx->first;
		if (nn->second.count(v) > 0) {
			double dis = xx->second.first + nn->second[v].first;
			if (distance > dis) {
				distance = dis;
			}
		}
	}
	return distance;

}


vector<pair<int, int>> graph_hash_of_mixed_weighted_PLL_extract_shortest_path(unordered_map<int, unordered_map<int, pair<double, int>>>& L, int source, int terminal) {

	vector<pair<int, int>> path; // edges

	while (source != terminal) {

		int capped_v;

		double distance = INT_MAX;
		auto mm = L.find(source);
		auto nn = L.find(terminal);
		for (auto xx = mm->second.begin(); xx != mm->second.end(); xx++) {
			int v = xx->first;
			if (nn->second.count(v) > 0) {
				double dis = xx->second.first + nn->second[v].first;
				if (distance > dis) {
					distance = dis;
					capped_v = v;
				}
			}
		}

		if (source != mm->second[capped_v].second) {
			path.push_back({ source , mm->second[capped_v].second });
			source = mm->second[capped_v].second; // ascending from source
		}

		if (terminal != nn->second[capped_v].second) {
			path.push_back({ terminal , nn->second[capped_v].second });
			terminal = nn->second[capped_v].second; // ascending from terminal
		}

	}

	return path;
}





#include <graph_hash_of_mixed_weighted/graph_hash_of_mixed_weighted_generate_random_connected_graph.h>
#include <graph_hash_of_mixed_weighted/graph_hash_of_mixed_weighted_read_graph_with_weight.h>
#include <graph_hash_of_mixed_weighted/graph_hash_of_mixed_weighted_save_graph_with_weight.h>

void simple_iterative_tests_forPLL() {

	/*parameters*/
	int iteration_times = 1;
	int V = 1000, E = 10000, precision = 3;
	double ec_min = 1, ec_max = 10;

	/*iteration*/
	std::time_t now = std::time(0);
	boost::random::mt19937 gen{ static_cast<std::uint32_t>(now) };
	for (int i = 0; i < iteration_times; i++) {

		/*input and output*/
		int generate_new_graph = 1;

		std::unordered_set<int> generated_group_vertices;
		graph_hash_of_mixed_weighted instance_graph, generated_group_graph;
		if (generate_new_graph == 1) {
			instance_graph = graph_hash_of_mixed_weighted_generate_random_connected_graph(V, E, 0, 0, ec_min, ec_max, precision);
			graph_hash_of_mixed_weighted_save_graph_with_weight("simple_iterative_tests.txt", instance_graph, 0);
		}
		else {
			double lambda;
			graph_hash_of_mixed_weighted_read_graph_with_weight("simple_iterative_tests.txt", instance_graph, lambda);
		}

		graph_hash_of_mixed_weighted_PLL_Create_Indexes(instance_graph, "simple_iterative_tests_PLL_Indexes.txt");

		unordered_map<int, unordered_map<int, pair<double, int>>> L = graph_hash_of_mixed_weighted_PLL_Read_Indexes("simple_iterative_tests_PLL_Indexes.txt");

		boost::random::uniform_int_distribution<> dist{ static_cast<int>(0), static_cast<int>(V - 1) };
		int source = dist(gen);

		std::unordered_map<int, double> distances;
		std::unordered_map<int, int> predecessors;
		graph_hash_of_mixed_weighted_shortest_paths_source_to_all(instance_graph, source, distances, predecessors);

		for (int xx = 0; xx < 10; xx++) {
			int terminal = dist(gen);
			double dis = graph_hash_of_mixed_weighted_PLL_extract_distance(L, source, terminal);
			if (abs(dis - distances[terminal]) > 1e-5) {
				cout << "dis = " << dis << endl;
				cout << "distances[terminal] = " << distances[terminal] << endl;
				cout << "abs(dis - distances[terminal]) > 1e-5!" << endl;
				getchar();
			}
			vector<pair<int, int>> path = graph_hash_of_mixed_weighted_PLL_extract_shortest_path(L, source, terminal);
			double path_dis = 0;
			for (auto it = path.begin(); it != path.end(); it++) {
				path_dis = path_dis + graph_hash_of_mixed_weighted_edge_weight(instance_graph, it->first, it->second);
			}
			if (abs(dis - path_dis) > 1e-5) {
				cout << "source = " << source << endl;
				cout << "terminal = " << terminal << endl;
				print_vector_pair_int(path);
				cout << "dis = " << dis << endl;
				cout << "path_dis = " << path_dis << endl;
				cout << "abs(dis - path_dis) > 1e-5!" << endl;
				getchar();
			}

		}
	}
}

