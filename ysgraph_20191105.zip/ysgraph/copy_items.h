#pragma once


std::vector<int> copy_vector_int(std::vector<int>& input_vector) {

	return input_vector;

}